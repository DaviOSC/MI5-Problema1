package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
)

type ServerResponse struct {
	Status string      `json:"status"`
	Data   interface{} `json:"data"`
}

func main() {
	// Conectar ao servidor
	conn, err := net.Dial("tcp", "localhost:8080")
	if err != nil {
		log.Fatal("Erro ao conectar ao servidor:", err)
	}
	defer conn.Close()

	var message struct {
		Choice string          `json:"choice"`
		ID     int             `json:"id"`
		Data   json.RawMessage `json:"data"`
	}
	message.Choice = "list_cars"
	buf, err := json.Marshal(message)
	if err != nil {
		log.Fatal("Erro ao serializar a mensagem:", err)
	}

	_, err = conn.Write(buf)
	if err != nil {
		log.Fatal("Erro ao enviar dados:", err)
	}

	// Receber a resposta do servidor
	var response ServerResponse
	decoder := json.NewDecoder(conn)
	err = decoder.Decode(&response)
	if err != nil {
		log.Fatal("Erro ao decodificar a resposta:", err)
	}

	// Mostrar a resposta
	fmt.Println("Status:", response.Status)
	if response.Data != nil {
		fmt.Printf("Dados recebidos: %+v\n", response.Data)
	}

	for {
		fmt.Println("Escolha um carro acima pelo id")
		fmt.Scanln(&message.ID)
		message.Choice = "teste"

		// Enviar a mensagem ao servidor
		buf, err := json.Marshal(message)
		if err != nil {
			log.Fatal("Erro ao serializar a mensagem:", err)
		}

		_, err = conn.Write(buf)
		if err != nil {
			log.Fatal("Erro ao enviar dados:", err)
		}

		// Receber a resposta do servidor
		var response ServerResponse
		decoder := json.NewDecoder(conn)
		err = decoder.Decode(&response)
		if err != nil {
			log.Fatal("Erro ao decodificar a resposta:", err)
		}

		// Mostrar a resposta
		fmt.Println("Status:", response.Status)
		if response.Data != nil {
			fmt.Printf("Dados recebidos: %+v\n", response.Data)
		}

		message.Choice = "get_best_station"
		buf, err = json.Marshal(message)
		if err != nil {
			log.Fatal("Erro ao serializar a mensagem:", err)
		}

		_, err = conn.Write(buf)
		if err != nil {
			log.Fatal("Erro ao enviar dados:", err)
		}

		err = decoder.Decode(&response)
		if err != nil {
			log.Fatal("Erro ao decodificar a resposta:", err)
		}

		// Mostrar a resposta
		fmt.Println("Status:", response.Status)
		if response.Data != nil {
			fmt.Printf("Dados recebidos: %+v\n", response.Data)
		}

	}
}
