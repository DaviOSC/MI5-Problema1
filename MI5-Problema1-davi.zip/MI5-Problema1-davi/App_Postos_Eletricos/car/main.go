package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"main/types"
)

type ServerResponse struct {
	Status string      `json:"status"`
	Data   interface{} `json:"data"`
}

func main() {
	// Conectar ao servidor
	conn, err := net.Dial("tcp", "localhost:8080")
	if err != nil {
		log.Fatal("Erro ao conectar ao servidor:", err)
	}
	defer conn.Close()

	for {
		// Menu para o cliente escolher o que fazer
		var choice string
		fmt.Println("Escolha uma opção:")
		fmt.Println("1 - Registrar um Carro")
		fmt.Println("2 - Consultar informações de um Carro")
		fmt.Println("3 - Listar todos os Carros")
		fmt.Print("Escolha: ")
		fmt.Scanln(&choice)

		var message struct {
			Choice string `json:"choice"`
			ID     int    `json:"id"`
			Data   json.RawMessage `json:"data"`
		}

		// Processar a escolha
		switch choice {
		case "1":
			message.Choice = "register_car"
			var car types.Car
			fmt.Print("Digite o ID do carro: ")
			fmt.Scanln(&car.CarID)
			fmt.Print("Digite a coordenada X do carro: ")
			fmt.Scanln(&car.CoordX)
			fmt.Print("Digite a coordenada Y do carro: ")
			fmt.Scanln(&car.CoordY)
			fmt.Print("Digite o nível da bateria: ")
			fmt.Scanln(&car.BatteryLevel)
			message.ID = car.CarID
			message.Data, _ = json.Marshal(car)

		case "2":
			message.Choice = "get_car"
			fmt.Print("Digite o ID do carro para consulta: ")
			fmt.Scanln(&message.ID)

		case "3":
			message.Choice = "list_cars"

		default:
			fmt.Println("Opção inválida.")
			return
		}

		// Enviar a mensagem ao servidor
		buf, err := json.Marshal(message)
		if err != nil {
			log.Fatal("Erro ao serializar a mensagem:", err)
		}

		_, err = conn.Write(buf)
		if err != nil {
			log.Fatal("Erro ao enviar dados:", err)
		}

		// Receber a resposta do servidor
		var response ServerResponse
		decoder := json.NewDecoder(conn)
		err = decoder.Decode(&response)
		if err != nil {
			log.Fatal("Erro ao decodificar a resposta:", err)
		}

		// Mostrar a resposta
		fmt.Println("Status:", response.Status)
		if response.Data != nil {
			fmt.Printf("Dados recebidos: %+v\n", response.Data)
		}
	}
}
