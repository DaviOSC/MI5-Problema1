# Usa a imagem oficial do Go
FROM golang:latest

WORKDIR /app

COPY . .

RUN go build -o carImage car/main.go

EXPOSE 8080

CMD ["./carImage"]
